<?php
/**
 * Plugin Name: Smart WebP Converter
 * Plugin URI: https://firexcore.com/blog/webp-image-optimization-for-wordpress/
 * Description: Automatically converts uploaded images to WebP format for better performance.
 * Version: 1.0.0
 * Author: FireXCore
 * Author URI: https://firexcore.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: smart-webp-converter
 * Domain Path: /languages
 */

defined('ABSPATH') or die('No script kiddies please!');

class FireXCore_WebP_Converter {
    private $quality;
    private $replace_original;
    private $supported_mimes;
    private $error_log;

    public function __construct() {
        $this->error_log = [];
        add_action('plugins_loaded', [$this, 'init']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);
        register_activation_hook(__FILE__, [$this, 'activate_plugin']);
    }

    public function init() {
        $this->load_textdomain();
        $this->set_options();
        $this->hooks();
        $this->check_plugin_compatibility();
    }

    public function activate_plugin() {
        if (!extension_loaded('gd')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die('This plugin requires the GD extension to be installed.');
        }
    }

    private function load_textdomain() {
        load_plugin_textdomain('smart-webp-converter', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    private function set_options() {
        $this->quality = get_option('firexcore_webp_quality', 80);
        $this->replace_original = get_option('firexcore_webp_replace_original', false);
        $this->supported_mimes = apply_filters('firexcore_webp_supported_mimes', [
            'image/jpeg', 'image/png', 'image/gif'
        ]);
    }

    private function hooks() {
        add_action('wp_update_attachment_metadata', [$this, 'process_image_conversion'], 10, 2);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_filter('wp_handle_upload', [$this, 'handle_upload'], 10, 2);
        add_action('admin_notices', [$this, 'display_error_notices']);
    }

    public function process_image_conversion($metadata, $attachment_id) {
        $file_path = wp_normalize_path(get_attached_file($attachment_id));

        if (!file_exists($file_path) || !$this->is_supported_mime(get_post_mime_type($attachment_id))) {
            $this->log_error("Unsupported file type or file not found for attachment ID: $attachment_id");
            return $metadata;
        }

        $webp_path = $this->create_webp_file($file_path);

        if (!$webp_path) {
            $this->log_error("WebP conversion failed for attachment ID: $attachment_id");
            return $metadata;
        }

        if ($this->replace_original) {
            $this->replace_original_file($attachment_id, $file_path, $webp_path);
        }

        return $metadata;
    }

    public function handle_upload($upload, $context = 'upload') {
        return $upload;
    }

    private function is_supported_mime($mime_type) {
        return in_array($mime_type, $this->supported_mimes);
    }

    private function create_webp_file($file_path) {
        if (!function_exists('imagewebp')) {
            $this->log_error('WebP conversion is not supported on this server.');
            return false;
        }

        $image = $this->create_image_resource($file_path);
        if (!$image) {
            return false;
        }

        $webp_path = preg_replace('/\.(jpg|jpeg|png|gif)$/i', '.webp', $file_path);
        imagewebp($image, $webp_path, $this->quality);
        imagedestroy($image);

        return file_exists($webp_path) ? $webp_path : false;
    }

    private function create_image_resource($file_path) {
        $image_type = exif_imagetype($file_path);
        if (!$image_type) {
            $this->log_error("Unsupported image type for file: $file_path");
            return false;
        }

        switch ($image_type) {
            case IMAGETYPE_JPEG:
                return imagecreatefromjpeg($file_path);
            case IMAGETYPE_PNG:
                return imagecreatefrompng($file_path);
            case IMAGETYPE_GIF:
                return imagecreatefromgif($file_path);
            default:
                $this->log_error("Unsupported image type for file: $file_path");
                return false;
        }
    }

    private function replace_original_file($attachment_id, $original_path, $webp_path) {
        if (file_exists($original_path)) {
            wp_delete_file($original_path); // Use WordPress function instead of unlink()
            update_attached_file($attachment_id, $webp_path);
            wp_update_post([
                'ID' => $attachment_id,
                'post_mime_type' => 'image/webp'
            ]);

            // Update metadata
            $metadata = wp_generate_attachment_metadata($attachment_id, $webp_path);
            wp_update_attachment_metadata($attachment_id, $metadata);
        } else {
            $this->log_error("Original file not found for attachment ID: $attachment_id");
        }
    }

    public function register_settings() {
        register_setting('firexcore_webp_options', 'firexcore_webp_quality', [
            'type' => 'integer',
            'sanitize_callback' => [$this, 'sanitize_quality'],
        ]);
        register_setting('firexcore_webp_options', 'firexcore_webp_replace_original', [
            'type' => 'boolean',
            'sanitize_callback' => [$this, 'sanitize_replace_original']
        ]);
    }

    public function sanitize_quality($input) {
        return intval(min(max($input, 0), 100));
    }

    public function sanitize_replace_original($input) {
        return filter_var($input, FILTER_VALIDATE_BOOLEAN);
    }

    public function add_settings_page() {
        add_options_page(
            __('Smart WebP Converter Settings', 'smart-webp-converter'),
            __('Smart WebP Converter', 'smart-webp-converter'),
            'manage_options',
            'smart-webp-converter',
            [$this, 'render_settings_page']
        );
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('firexcore_webp_options');
                do_settings_sections('firexcore_webp_options');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e('WebP Quality', 'smart-webp-converter'); ?></th>
                        <td>
                            <input type="number" name="firexcore_webp_quality" value="<?php echo esc_attr(get_option('firexcore_webp_quality', 80)); ?>" min="0" max="100" />
                            <p class="description"><?php esc_html_e('Quality of WebP image (0-100)', 'smart-webp-converter'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Replace Original', 'smart-webp-converter'); ?></th>
                        <td>
                            <input type="checkbox" name="firexcore_webp_replace_original" value="1" <?php checked(get_option('firexcore_webp_replace_original', false)); ?> />
                            <p class="description"><?php esc_html_e('Replace original image with WebP version', 'smart-webp-converter'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function add_settings_link($links) {
        $settings_link = '<a href="options-general.php?page=smart-webp-converter">' . esc_html__('Settings', 'smart-webp-converter') . '</a>'; // Escaped output
        array_push($links, $settings_link);
        return $links;
    }

    public function display_error_notices() {
        if (!empty($this->error_log)) {
            foreach ($this->error_log as $error) {
                echo '<div class="notice notice-error"><p>' . esc_html($error) . '</p></div>';
            }
        }
    }

    private function log_error($message) {
        $this->error_log[] = $message;
    }

    private function check_plugin_compatibility() {
        if (!function_exists('imagewebp')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-warning"><p>' . esc_html__('WebP support is not available on this server.', 'smart-webp-converter') . '</p></div>';
            });
        }
    }
}

new FireXCore_WebP_Converter();
