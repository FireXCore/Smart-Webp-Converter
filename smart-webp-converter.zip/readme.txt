=== Smart WebP Converter ===
Contributors: FireXCore
Tags: webp, image conversion, performance, optimize, image
Requires at least: 5.0
Tested up to: 6.6
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically converts uploaded images to WebP for better performance and optimization, saving storage and improving website speed.

== Description ==

Smart WebP Converter converts JPEG, PNG, and GIF images to WebP on upload, improving website speed and saving storage with superior compression.

Main features include:
- Automatically converts JPEG, PNG, and GIF images to WebP.
- Option to replace original images with WebP versions to save storage space.
- Quality adjustment for WebP images (0-100 scale).
- Supports WooCommerce and any WordPress media uploader.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/smart-webp-converter` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to the settings page under 'Settings' > 'WebP Converter' to configure the plugin.
4. Adjust the WebP quality or enable the option to replace original images with WebP versions if desired.

== Frequently Asked Questions ==

= How does the plugin work? =

When you upload an image (JPEG, PNG, or GIF), this plugin automatically converts it to WebP format using WordPress hooks. You can also choose to delete the original image to save space.

= Can I control the quality of the WebP images? =

Yes, you can set the quality level (between 0-100) for WebP images on the settings page.

= Will this plugin replace the original images? =

You have the option to either keep the original images or replace them with the WebP versions.

= Does the plugin work with WooCommerce? =

Yes, it works seamlessly with WooCommerce, converting product images to WebP.

= What if my server does not support WebP? =

If your server does not support WebP conversion (for example, if the `imagewebp` function is not available), the plugin will log an error and skip the conversion process.

== Screenshots ==

1. **Settings Page**: Adjust WebP quality and decide whether to replace the original images.
2. **Media Upload**: Images are converted to WebP upon upload.

== Changelog ==

= 1.0.0 =
* Initial release of the plugin.
* Convert uploaded images (JPEG, PNG, GIF) to WebP format.
* Option to replace original images with WebP versions.
* Quality adjustment for WebP images.

== Upgrade Notice ==

= 1.0.0 =
Initial release of Smart WebP Converter. Install this version to automatically optimize your images with WebP format.

== License ==

This plugin is licensed under the GPL v2 or later. For more information, visit [GPL License](https://www.gnu.org/licenses/gpl-2.0.html).
